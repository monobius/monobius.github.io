-----------------------------------
       "SMALL MOOG DRUM KIT"       
          Roger Hallaway
           August 2020
-----------------------------------

Thank you for downloading the SMALL
MOOG DRUM KIT by Roger Hallaway.
This folder contains 25 WAV files
made up of 2 cymbals, 4 hi-hats, 8
bass drums, 3 snares, 4 toms, and 4
triangles.

All of these samples were created
on my Behringer Model D Analog
Synthesizer (a faithful creation of
the original Moog MiniMoog Model D
Analog Synthesizer). They were
recorded through my Warm Audio WA12
microphone preamp, which also
contributed to their dark timbre.

No digital post-processing has been
applied to these samples (apart
from volume automation being
applied to smoothly fade out each
sample).

The samples are approximately tuned
to the key of C Major, but can
easily be retuned in most DAWs by
using repitching technology.

===================================
       WHY DOES THIS EXIST ?
===================================

Analog synthesizers can be
expensive and inaccessible for many
artists. The SMALL MOOG DRUM KIT
has been put together to provide
artists with access to these
sounds for free.

This work is licensed under the
Creative Commons Attribution 4.0
International License. To view a
copy of this license, visit
https://creativecommons.org/
licenses/by/4.0/.

===================================
        CONTACT INFORMATION        
===================================

If you have any questions, feel
free to visit my website at
https://www.monobius.com for more
information, products, and news.